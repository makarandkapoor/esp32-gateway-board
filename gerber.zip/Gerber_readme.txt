The Gerber files are generated from eagle EDA tool. The gerber.zip contains following files: 

1.  board.gtl Contains  Top layer copper, Pads and Vias 
2.  board.gbl Contains  Bottom layer copper, Pads and Vias 
3.  board.gts Contains  Top layer Solder mask 
4.  board.gbs Contains  Bottom layer Solder  mask 
5.  board.gto Contains  Top layer Silkscreen 
6.  board.gbo Contains  Bottom layer Silkscreen 
7.  board.gtp Contains  Top layer Solderpaste 
8.  board.gbp Contains  Bottom layer Solderpaste 
9.  board.xln Contains  drill file in Excellon file format 
10. board.gko Contains  board outline file 

Here are some additional facts which may be needed by the manufacturer:
1. Units : mm 
2. Files have been tested to work with gerber viewer 

